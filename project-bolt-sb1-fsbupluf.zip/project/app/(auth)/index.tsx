import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowRight } from 'lucide-react-native';

export default function Welcome() {
  const { width } = useWindowDimensions();
  const isSmallScreen = width < 768;

  return (
    <LinearGradient
      colors={['#0B3D91', '#102C57']}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.logo}>MarketMagic</Text>
        </View>

        <View style={[styles.content, isSmallScreen ? styles.contentSmall : styles.contentLarge]}>
          <View style={styles.textContainer}>
            <Text style={styles.title}>
              Your All-in-One{'\n'}
              Digital Marketing Solution
            </Text>
            <Text style={styles.subtitle}>
              Empower your business with AI-driven marketing tools designed for small businesses
            </Text>

            <View style={styles.features}>
              <View style={styles.featureRow}>
                <View style={styles.featureItem}>
                  <View style={styles.featureIcon}>
                    <Text style={styles.featureIconText}>✓</Text>
                  </View>
                  <Text style={styles.featureText}>Content Generation</Text>
                </View>
                <View style={styles.featureItem}>
                  <View style={styles.featureIcon}>
                    <Text style={styles.featureIconText}>✓</Text>
                  </View>
                  <Text style={styles.featureText}>SEO Tools</Text>
                </View>
              </View>
              <View style={styles.featureRow}>
                <View style={styles.featureItem}>
                  <View style={styles.featureIcon}>
                    <Text style={styles.featureIconText}>✓</Text>
                  </View>
                  <Text style={styles.featureText}>Social Media Management</Text>
                </View>
                <View style={styles.featureItem}>
                  <View style={styles.featureIcon}>
                    <Text style={styles.featureIconText}>✓</Text>
                  </View>
                  <Text style={styles.featureText}>Performance Analytics</Text>
                </View>
              </View>
            </View>
          </View>

          {!isSmallScreen && (
            <View style={styles.imageContainer}>
              <Image
                source={{ uri: 'https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg' }}
                style={styles.image}
                resizeMode="cover"
              />
            </View>
          )}
        </View>

        <View style={styles.buttonsContainer}>
          <TouchableOpacity 
            style={styles.buttonPrimary}
            onPress={() => router.push('/register')}
          >
            <Text style={styles.buttonPrimaryText}>Get Started</Text>
            <ArrowRight size={20} color="#FFF" />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.buttonSecondary}
            onPress={() => router.push('/login')}
          >
            <Text style={styles.buttonSecondaryText}>Sign In</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 24,
  },
  header: {
    paddingTop: 40,
    alignItems: 'center',
  },
  logo: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },
  content: {
    flex: 1,
    paddingVertical: 40,
  },
  contentSmall: {
    flexDirection: 'column',
  },
  contentLarge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontFamily: 'Poppins-Bold',
    fontSize: 32,
    lineHeight: 40,
    color: '#FFFFFF',
    marginBottom: 16,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    lineHeight: 24,
    color: 'rgba(255, 255, 255, 0.8)',
    marginBottom: 32,
  },
  features: {
    marginTop: 24,
  },
  featureRow: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
    flex: 1,
  },
  featureIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FF6B6B',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  featureIconText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  featureText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#FFFFFF',
    flex: 1,
  },
  imageContainer: {
    flex: 1,
    marginLeft: 40,
    height: 400,
    borderRadius: 16,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  buttonsContainer: {
    marginTop: 40,
  },
  buttonPrimary: {
    backgroundColor: '#FF6B6B',
    borderRadius: 8,
    paddingVertical: 16,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  buttonPrimaryText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    marginRight: 8,
  },
  buttonSecondary: {
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.5)',
    borderRadius: 8,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  buttonSecondaryText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: '#FFFFFF',
  },
});