import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import { Calendar, TrendingUp, Users, Smartphone, Laptop } from 'lucide-react-native';

export default function AnalyticsScreen() {
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'year'>('month');
  const screenWidth = Dimensions.get('window').width - 40;
  
  const chartConfig = {
    backgroundGradientFrom: '#FFFFFF',
    backgroundGradientTo: '#FFFFFF',
    color: (opacity = 1) => `rgba(11, 61, 145, ${opacity})`,
    strokeWidth: 2,
    barPercentage: 0.5,
    useShadowColorFromDataset: false,
    propsForDots: {
      r: '6',
      strokeWidth: '2',
      stroke: '#0B3D91'
    },
    propsForLabels: {
      fontFamily: 'Inter-Regular',
      fontSize: 10,
    },
  };
  
  const websiteData = {
    week: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [
        {
          data: [25, 30, 15, 40, 35, 20, 45],
          color: (opacity = 1) => `rgba(11, 61, 145, ${opacity})`,
          strokeWidth: 2,
        },
      ],
    },
    month: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
      datasets: [
        {
          data: [120, 180, 140, 210],
          color: (opacity = 1) => `rgba(11, 61, 145, ${opacity})`,
          strokeWidth: 2,
        },
      ],
    },
    year: {
      labels: ['Jan', 'Mar', 'May', 'Jul', 'Sep', 'Nov'],
      datasets: [
        {
          data: [400, 550, 750, 620, 800, 920],
          color: (opacity = 1) => `rgba(11, 61, 145, ${opacity})`,
          strokeWidth: 2,
        },
      ],
    },
  };
  
  const socialData = {
    week: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [
        {
          data: [45, 38, 52, 65, 48, 70, 68],
          color: (opacity = 1) => `rgba(255, 107, 107, ${opacity})`,
          strokeWidth: 2,
        },
      ],
    },
    month: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
      datasets: [
        {
          data: [200, 250, 180, 310],
          color: (opacity = 1) => `rgba(255, 107, 107, ${opacity})`,
          strokeWidth: 2,
        },
      ],
    },
    year: {
      labels: ['Jan', 'Mar', 'May', 'Jul', 'Sep', 'Nov'],
      datasets: [
        {
          data: [1200, 1500, 1300, 1800, 2100, 2400],
          color: (opacity = 1) => `rgba(255, 107, 107, ${opacity})`,
          strokeWidth: 2,
        },
      ],
    },
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Analytics</Text>
      </View>
      
      <View style={styles.timeframeSelector}>
        <TouchableOpacity
          style={[styles.timeframeButton, timeframe === 'week' && styles.timeframeButtonActive]}
          onPress={() => setTimeframe('week')}
        >
          <Text style={[styles.timeframeText, timeframe === 'week' && styles.timeframeTextActive]}>Week</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.timeframeButton, timeframe === 'month' && styles.timeframeButtonActive]}
          onPress={() => setTimeframe('month')}
        >
          <Text style={[styles.timeframeText, timeframe === 'month' && styles.timeframeTextActive]}>Month</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.timeframeButton, timeframe === 'year' && styles.timeframeButtonActive]}
          onPress={() => setTimeframe('year')}
        >
          <Text style={[styles.timeframeText, timeframe === 'year' && styles.timeframeTextActive]}>Year</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.summaryRow}>
        <View style={styles.summaryCard}>
          <View style={styles.summaryIconContainer}>
            <TrendingUp size={20} color="#0B3D91" />
          </View>
          <Text style={styles.summaryValue}>1,245</Text>
          <Text style={styles.summaryLabel}>Total Visits</Text>
        </View>
        
        <View style={styles.summaryCard}>
          <View style={styles.summaryIconContainer}>
            <Users size={20} color="#0B3D91" />
          </View>
          <Text style={styles.summaryValue}>835</Text>
          <Text style={styles.summaryLabel}>Unique Visitors</Text>
        </View>
      </View>
      
      <View style={styles.chartContainer}>
        <View style={styles.chartHeader}>
          <Text style={styles.chartTitle}>Website Traffic</Text>
          <View style={styles.dateRange}>
            <Calendar size={16} color="#6B7280" />
            <Text style={styles.dateRangeText}>
              {timeframe === 'week' ? 'Last 7 days' : timeframe === 'month' ? 'Last 30 days' : 'Last 12 months'}
            </Text>
          </View>
        </View>
        
        <LineChart
          data={websiteData[timeframe]}
          width={screenWidth}
          height={220}
          chartConfig={chartConfig}
          bezier
          style={styles.chart}
        />
      </View>
      
      <View style={styles.platformsContainer}>
        <Text style={styles.sectionTitle}>Traffic by Device</Text>
        
        <View style={styles.platformRow}>
          <View style={styles.platformItem}>
            <View style={[styles.platformIcon, { backgroundColor: '#E0F2FE' }]}>
              <Smartphone size={20} color="#0369A1" />
            </View>
            <View style={styles.platformInfo}>
              <Text style={styles.platformName}>Mobile</Text>
              <Text style={styles.platformValue}>65%</Text>
            </View>
          </View>
          
          <View style={styles.platformItem}>
            <View style={[styles.platformIcon, { backgroundColor: '#FEF3C7' }]}>
              <Laptop size={20} color="#B45309" />
            </View>
            <View style={styles.platformInfo}>
              <Text style={styles.platformName}>Desktop</Text>
              <Text style={styles.platformValue}>35%</Text>
            </View>
          </View>
        </View>
      </View>
      
      <View style={styles.chartContainer}>
        <View style={styles.chartHeader}>
          <Text style={styles.chartTitle}>Social Media Engagement</Text>
          <View style={styles.dateRange}>
            <Calendar size={16} color="#6B7280" />
            <Text style={styles.dateRangeText}>
              {timeframe === 'week' ? 'Last 7 days' : timeframe === 'month' ? 'Last 30 days' : 'Last 12 months'}
            </Text>
          </View>
        </View>
        
        <LineChart
          data={socialData[timeframe]}
          width={screenWidth}
          height={220}
          chartConfig={{
            ...chartConfig,
            color: (opacity = 1) => `rgba(255, 107, 107, ${opacity})`,
          }}
          bezier
          style={styles.chart}
        />
      </View>
      
      <View style={styles.platformsContainer}>
        <Text style={styles.sectionTitle}>Top Channels</Text>
        
        <View style={styles.channelList}>
          <View style={styles.channelItem}>
            <View style={styles.channelName}>
              <View style={[styles.channelDot, { backgroundColor: '#0B3D91' }]} />
              <Text style={styles.channelText}>Organic Search</Text>
            </View>
            <Text style={styles.channelValue}>42%</Text>
          </View>
          
          <View style={styles.channelItem}>
            <View style={styles.channelName}>
              <View style={[styles.channelDot, { backgroundColor: '#FF6B6B' }]} />
              <Text style={styles.channelText}>Social Media</Text>
            </View>
            <Text style={styles.channelValue}>28%</Text>
          </View>
          
          <View style={styles.channelItem}>
            <View style={styles.channelName}>
              <View style={[styles.channelDot, { backgroundColor: '#10B981' }]} />
              <Text style={styles.channelText}>Direct</Text>
            </View>
            <Text style={styles.channelValue}>18%</Text>
          </View>
          
          <View style={styles.channelItem}>
            <View style={styles.channelName}>
              <View style={[styles.channelDot, { backgroundColor: '#F59E0B' }]} />
              <Text style={styles.channelText}>Referral</Text>
            </View>
            <Text style={styles.channelValue}>12%</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  contentContainer: {
    paddingBottom: 40,
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 24,
    color: '#1F2937',
  },
  timeframeSelector: {
    flexDirection: 'row',
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  timeframeButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
    backgroundColor: '#F3F4F6',
  },
  timeframeButtonActive: {
    backgroundColor: '#0B3D91',
  },
  timeframeText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#6B7280',
  },
  timeframeTextActive: {
    color: '#FFFFFF',
  },
  summaryRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  summaryCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginRight: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  summaryIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#EBF5FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  summaryValue: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: '#1F2937',
    marginBottom: 4,
  },
  summaryLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#6B7280',
  },
  chartContainer: {
    backgroundColor: '#FFFFFF',
    margin: 20,
    marginTop: 8,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  chartTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#1F2937',
  },
  dateRange: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateRangeText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#6B7280',
    marginLeft: 4,
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16,
  },
  platformsContainer: {
    backgroundColor: '#FFFFFF',
    margin: 20,
    marginTop: 0,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#1F2937',
    marginBottom: 16,
  },
  platformRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  platformItem: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '48%',
  },
  platformIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  platformInfo: {
    flex: 1,
  },
  platformName: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#4B5563',
  },
  platformValue: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#1F2937',
  },
  channelList: {
    marginTop: 8,
  },
  channelItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  channelName: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  channelDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  channelText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#4B5563',
  },
  channelValue: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#1F2937',
  },
});