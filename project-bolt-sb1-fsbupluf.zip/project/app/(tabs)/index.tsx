import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, useWindowDimensions } from 'react-native';
import { Rocket, TrendingUp, Target, Calendar, Plus, ArrowRight } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { useSubscription } from '@/contexts/SubscriptionContext';
import { LinearGradient } from 'expo-linear-gradient';

export default function Dashboard() {
  const { user } = useAuth();
  const { currentPlan } = useSubscription();
  const { width } = useWindowDimensions();
  const isSmallScreen = width < 768;

  const marketingStats = [
    { title: 'Social Reach', value: '2.4K', change: '+12%', isPositive: true },
    { title: 'Website Visits', value: '847', change: '+8%', isPositive: true },
    { title: 'Engagement Rate', value: '3.2%', change: '-1%', isPositive: false },
    { title: 'Conversion Rate', value: '2.1%', change: '+0.5%', isPositive: true },
  ];

  const recentCampaigns = [
    { id: '1', name: 'Summer Sale Promotion', status: 'Active', performance: 'Good', date: '2025-06-15' },
    { id: '2', name: 'Product Launch Email', status: 'Scheduled', performance: 'Pending', date: '2025-07-01' },
    { id: '3', name: 'Blog Content Series', status: 'Draft', performance: 'Pending', date: 'N/A' },
  ];

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 18) return 'Good Afternoon';
    return 'Good Evening';
  };

  const renderStatusBadge = (status: string) => {
    let backgroundColor, textColor;
    
    switch (status) {
      case 'Active':
        backgroundColor = '#DCFCE7';
        textColor = '#15803D';
        break;
      case 'Scheduled':
        backgroundColor = '#E0F2FE';
        textColor = '#0369A1';
        break;
      case 'Draft':
        backgroundColor = '#F3F4F6';
        textColor = '#4B5563';
        break;
      default:
        backgroundColor = '#F3F4F6';
        textColor = '#4B5563';
    }
    
    return (
      <View style={[styles.statusBadge, { backgroundColor }]}>
        <Text style={[styles.statusText, { color: textColor }]}>{status}</Text>
      </View>
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>{greeting()}</Text>
          <Text style={styles.userName}>{user?.name || 'User'}</Text>
        </View>
        <View style={styles.planBadge}>
          <Text style={styles.planText}>{currentPlan?.name || 'Free'} Plan</Text>
        </View>
      </View>
      
      <LinearGradient
        colors={['#0B3D91', '#102C57']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.overviewCard}
      >
        <View style={styles.overviewTextContainer}>
          <Text style={styles.overviewTitle}>Marketing Overview</Text>
          <Text style={styles.overviewDescription}>
            Your marketing performance is showing positive trends this month.
          </Text>
          <TouchableOpacity style={styles.viewDetailsButton}>
            <Text style={styles.viewDetailsText}>View Details</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.overviewImageContainer}>
          <Rocket size={48} color="#FFFFFF" />
        </View>
      </LinearGradient>
      
      <Text style={styles.sectionTitle}>Marketing Stats</Text>
      
      <View style={[styles.statsGrid, isSmallScreen ? styles.statsGridSmall : styles.statsGridLarge]}>
        {marketingStats.map((stat, index) => (
          <View key={index} style={styles.statCard}>
            <Text style={styles.statTitle}>{stat.title}</Text>
            <Text style={styles.statValue}>{stat.value}</Text>
            <View style={styles.statChange}>
              <TrendingUp 
                size={14} 
                color={stat.isPositive ? '#15803D' : '#DC2626'} 
                style={{ marginRight: 4, transform: [{ rotate: stat.isPositive ? '0deg' : '180deg' }] }}
              />
              <Text 
                style={[
                  styles.statChangeText, 
                  { color: stat.isPositive ? '#15803D' : '#DC2626' }
                ]}
              >
                {stat.change}
              </Text>
            </View>
          </View>
        ))}
      </View>
      
      <View style={styles.quickActionsContainer}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        
        <View style={styles.quickActionsGrid}>
          <TouchableOpacity style={styles.quickActionCard}>
            <View style={[styles.quickActionIcon, { backgroundColor: '#E0F2FE' }]}>
              <FileEdit size={24} color="#0369A1" />
            </View>
            <Text style={styles.quickActionText}>Create Content</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.quickActionCard}>
            <View style={[styles.quickActionIcon, { backgroundColor: '#FEF3C7' }]}>
              <Target size={24} color="#B45309" />
            </View>
            <Text style={styles.quickActionText}>Keyword Research</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.quickActionCard}>
            <View style={[styles.quickActionIcon, { backgroundColor: '#DCFCE7' }]}>
              <Calendar size={24} color="#15803D" />
            </View>
            <Text style={styles.quickActionText}>Schedule Posts</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.campaignsContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent Campaigns</Text>
          <TouchableOpacity style={styles.viewAllButton}>
            <Text style={styles.viewAllText}>View All</Text>
            <ArrowRight size={16} color="#0B3D91" />
          </TouchableOpacity>
        </View>
        
        {recentCampaigns.map((campaign) => (
          <TouchableOpacity key={campaign.id} style={styles.campaignCard}>
            <View style={styles.campaignInfo}>
              <Text style={styles.campaignName}>{campaign.name}</Text>
              <View style={styles.campaignDetails}>
                <Text style={styles.campaignDate}>
                  {campaign.date === 'N/A' ? 'No date set' : new Date(campaign.date).toLocaleDateString()}
                </Text>
                {renderStatusBadge(campaign.status)}
              </View>
            </View>
            <ArrowRight size={20} color="#6B7280" />
          </TouchableOpacity>
        ))}
        
        <TouchableOpacity style={styles.createCampaignButton}>
          <Plus size={20} color="#0B3D91" />
          <Text style={styles.createCampaignText}>Create New Campaign</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  contentContainer: {
    padding: 20,
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  greeting: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#6B7280',
  },
  userName: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: '#1F2937',
  },
  planBadge: {
    backgroundColor: '#E0F2FE',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  planText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#0369A1',
  },
  overviewCard: {
    flexDirection: 'row',
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
  },
  overviewTextContainer: {
    flex: 3,
  },
  overviewTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#FFFFFF',
    marginBottom: 8,
  },
  overviewDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    marginBottom: 16,
  },
  viewDetailsButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  viewDetailsText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#FFFFFF',
  },
  overviewImageContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#1F2937',
    marginBottom: 16,
  },
  statsGrid: {
    marginBottom: 24,
  },
  statsGridSmall: {
    flexDirection: 'column',
  },
  statsGridLarge: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    width: '48%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  statTitle: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 8,
  },
  statValue: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: '#1F2937',
    marginBottom: 8,
  },
  statChange: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statChangeText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
  },
  quickActionsContainer: {
    marginBottom: 24,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  quickActionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    width: '31%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  quickActionText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#4B5563',
    textAlign: 'center',
  },
  campaignsContainer: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  viewAllText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#0B3D91',
    marginRight: 4,
  },
  campaignCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  campaignInfo: {
    flex: 1,
  },
  campaignName: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: '#1F2937',
    marginBottom: 8,
  },
  campaignDetails: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  campaignDate: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#6B7280',
    marginRight: 8,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  statusText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
  },
  createCampaignButton: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },
  createCampaignText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#0B3D91',
    marginLeft: 8,
  },
});