import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Image } from 'react-native';
import { useAuth } from '@/contexts/AuthContext';
import { useSubscription } from '@/contexts/SubscriptionContext';
import { CreditCard, Bell, Shield, HelpCircle, LogOut, ChevronRight } from 'lucide-react-native';
import { router } from 'expo-router';

export default function SettingsScreen() {
  const { user, signOut } = useAuth();
  const { currentPlan } = useSubscription();
  
  const [emailNotifications, setEmailNotifications] = React.useState(true);
  const [appNotifications, setAppNotifications] = React.useState(true);
  
  const handleUpgrade = () => {
    router.push('/subscription');
  };
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Settings</Text>
      </View>
      
      <View style={styles.profileSection}>
        <View style={styles.profileCard}>
          <View style={styles.profileHeader}>
            <View style={styles.avatarContainer}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>{getInitials(user?.name || 'User')}</Text>
              </View>
            </View>
            
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>{user?.name || 'User'}</Text>
              <Text style={styles.profileEmail}>{user?.email || 'user@example.com'}</Text>
              <View style={styles.profilePlan}>
                <Text style={styles.profilePlanText}>{currentPlan?.name || 'Free'} Plan</Text>
              </View>
            </View>
          </View>
          
          <TouchableOpacity style={styles.editProfileButton}>
            <Text style={styles.editProfileText}>Edit Profile</Text>
          </TouchableOpacity>
        </View>
        
        {currentPlan?.tier !== 'enterprise' && (
          <View style={styles.upgradeCard}>
            <View style={styles.upgradeInfo}>
              <Text style={styles.upgradeTitle}>Upgrade Your Plan</Text>
              <Text style={styles.upgradeDescription}>
                Get access to more features and higher usage limits
              </Text>
            </View>
            <TouchableOpacity style={styles.upgradeButton} onPress={handleUpgrade}>
              <Text style={styles.upgradeButtonText}>Upgrade</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
      
      <View style={styles.settingsSection}>
        <Text style={styles.sectionTitle}>Account Settings</Text>
        
        <View style={styles.settingsCard}>
          <TouchableOpacity style={styles.settingsItem}>
            <View style={styles.settingsItemIcon}>
              <CreditCard size={20} color="#0B3D91" />
            </View>
            <View style={styles.settingsItemContent}>
              <Text style={styles.settingsItemTitle}>Subscription & Billing</Text>
              <Text style={styles.settingsItemDescription}>Manage your plan and payment methods</Text>
            </View>
            <ChevronRight size={20} color="#9CA3AF" />
          </TouchableOpacity>
          
          <View style={styles.separator} />
          
          <View style={styles.settingsItem}>
            <View style={styles.settingsItemIcon}>
              <Bell size={20} color="#0B3D91" />
            </View>
            <View style={styles.settingsItemContent}>
              <Text style={styles.settingsItemTitle}>Notifications</Text>
              <Text style={styles.settingsItemDescription}>Control your notification preferences</Text>
              
              <View style={styles.notificationToggles}>
                <View style={styles.notificationToggle}>
                  <Text style={styles.toggleLabel}>Email notifications</Text>
                  <Switch
                    value={emailNotifications}
                    onValueChange={setEmailNotifications}
                    trackColor={{ false: '#D1D5DB', true: '#93C5FD' }}
                    thumbColor={emailNotifications ? '#0B3D91' : '#F3F4F6'}
                  />
                </View>
                
                <View style={styles.notificationToggle}>
                  <Text style={styles.toggleLabel}>App notifications</Text>
                  <Switch
                    value={appNotifications}
                    onValueChange={setAppNotifications}
                    trackColor={{ false: '#D1D5DB', true: '#93C5FD' }}
                    thumbColor={appNotifications ? '#0B3D91' : '#F3F4F6'}
                  />
                </View>
              </View>
            </View>
          </View>
          
          <View style={styles.separator} />
          
          <TouchableOpacity style={styles.settingsItem}>
            <View style={styles.settingsItemIcon}>
              <Shield size={20} color="#0B3D91" />
            </View>
            <View style={styles.settingsItemContent}>
              <Text style={styles.settingsItemTitle}>Security</Text>
              <Text style={styles.settingsItemDescription}>Change password and security settings</Text>
            </View>
            <ChevronRight size={20} color="#9CA3AF" />
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.supportSection}>
        <Text style={styles.sectionTitle}>Support</Text>
        
        <View style={styles.settingsCard}>
          <TouchableOpacity style={styles.settingsItem}>
            <View style={styles.settingsItemIcon}>
              <HelpCircle size={20} color="#0B3D91" />
            </View>
            <View style={styles.settingsItemContent}>
              <Text style={styles.settingsItemTitle}>Help & Support</Text>
              <Text style={styles.settingsItemDescription}>Get help with using the app</Text>
            </View>
            <ChevronRight size={20} color="#9CA3AF" />
          </TouchableOpacity>
          
          <View style={styles.separator} />
          
          <TouchableOpacity style={styles.settingsItem}>
            <View style={styles.settingsItemIcon}>
              <LogOut size={20} color="#EF4444" />
            </View>
            <View style={styles.settingsItemContent}>
              <Text style={[styles.settingsItemTitle, styles.logoutText]}>Log Out</Text>
            </View>
            <TouchableOpacity onPress={signOut}>
              <ChevronRight size={20} color="#9CA3AF" />
            </TouchableOpacity>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.appInfo}>
        <Text style={styles.appVersion}>MarketMagic v1.0.0</Text>
        <TouchableOpacity>
          <Text style={styles.appLink}>Terms of Service</Text>
        </TouchableOpacity>
        <TouchableOpacity>
          <Text style={styles.appLink}>Privacy Policy</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  contentContainer: {
    paddingBottom: 40,
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 24,
    color: '#1F2937',
  },
  profileSection: {
    padding: 20,
  },
  profileCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  profileHeader: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  avatarContainer: {
    marginRight: 16,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#0B3D91',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: '#FFFFFF',
  },
  profileInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  profileName: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#1F2937',
    marginBottom: 4,
  },
  profileEmail: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 8,
  },
  profilePlan: {
    backgroundColor: '#E0F2FE',
    borderRadius: 16,
    paddingHorizontal: 8,
    paddingVertical: 2,
    alignSelf: 'flex-start',
  },
  profilePlanText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#0369A1',
  },
  editProfileButton: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center',
  },
  editProfileText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#0B3D91',
  },
  upgradeCard: {
    backgroundColor: '#EBF5FF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: '#BFDBFE',
  },
  upgradeInfo: {
    flex: 1,
    marginRight: 16,
  },
  upgradeTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#1E40AF',
    marginBottom: 4,
  },
  upgradeDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#3B82F6',
  },
  upgradeButton: {
    backgroundColor: '#0B3D91',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  upgradeButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#FFFFFF',
  },
  settingsSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  supportSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#1F2937',
    marginBottom: 12,
  },
  settingsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  settingsItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  settingsItemIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  settingsItemContent: {
    flex: 1,
  },
  settingsItemTitle: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: '#1F2937',
    marginBottom: 4,
  },
  settingsItemDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#6B7280',
  },
  separator: {
    height: 1,
    backgroundColor: '#E5E7EB',
    marginLeft: 56,
  },
  notificationToggles: {
    marginTop: 12,
  },
  notificationToggle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 8,
  },
  toggleLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4B5563',
  },
  logoutText: {
    color: '#EF4444',
  },
  appInfo: {
    padding: 20,
    alignItems: 'center',
  },
  appVersion: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#9CA3AF',
    marginBottom: 8,
  },
  appLink: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#0B3D91',
    marginVertical: 4,
  },
});