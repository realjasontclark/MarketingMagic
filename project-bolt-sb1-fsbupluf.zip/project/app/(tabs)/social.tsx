import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Image } from 'react-native';
import { Calendar, Clock, Instagram, Facebook, Twitter, Linkedin, Plus, Send, Image as ImageIcon, Smile } from 'lucide-react-native';
import { useSubscription } from '@/contexts/SubscriptionContext';

export default function SocialScreen() {
  const { currentPlan, getFeatureLimit } = useSubscription();
  const [postText, setPostText] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(['instagram']);
  
  const maxPlatforms = getFeatureLimit('socialMedia.platforms') || 1;
  const hasScheduling = getFeatureLimit('socialMedia.scheduling') || false;
  
  const platforms = [
    { id: 'instagram', name: 'Instagram', icon: Instagram, color: '#E1306C' },
    { id: 'facebook', name: 'Facebook', icon: Facebook, color: '#1877F2' },
    { id: 'twitter', name: 'Twitter', icon: Twitter, color: '#1DA1F2' },
    { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: '#0A66C2' },
  ];
  
  const scheduledPosts = [
    { 
      id: '1', 
      content: 'Excited to announce our latest product update! Check out the new features on our website.',
      platforms: ['instagram', 'facebook'],
      scheduledFor: '2025-07-15T10:00:00',
      image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    { 
      id: '2', 
      content: 'Join us for our upcoming webinar on digital marketing strategies for small businesses.',
      platforms: ['linkedin', 'twitter'],
      scheduledFor: '2025-07-20T14:30:00',
      image: null
    },
  ];
  
  const draftPosts = [
    { 
      id: '1', 
      content: 'Looking for the best tools to grow your business? Here are our top 5 recommendations...',
      platforms: ['instagram'],
      image: 'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
  ];
  
  const togglePlatform = (platformId: string) => {
    if (selectedPlatforms.includes(platformId)) {
      setSelectedPlatforms(selectedPlatforms.filter(id => id !== platformId));
    } else {
      if (selectedPlatforms.length < maxPlatforms) {
        setSelectedPlatforms([...selectedPlatforms, platformId]);
      }
    }
  };
  
  const formatScheduleDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };
  
  const formatScheduleTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };
  
  const renderPlatformIcon = (platformId: string, size: number = 20) => {
    const platform = platforms.find(p => p.id === platformId);
    if (!platform) return null;
    
    const IconComponent = platform.icon;
    return <IconComponent size={size} color={platform.color} style={{ marginRight: size > 20 ? 8 : 4 }} />;
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Social Media</Text>
      </View>
      
      <View style={styles.composeCard}>
        <Text style={styles.composeTitle}>Create Post</Text>
        
        <View style={styles.platformSelector}>
          <Text style={styles.selectorLabel}>
            Select Platforms ({selectedPlatforms.length}/{maxPlatforms})
          </Text>
          <View style={styles.platformButtons}>
            {platforms.map(platform => (
              <TouchableOpacity
                key={platform.id}
                style={[
                  styles.platformButton,
                  selectedPlatforms.includes(platform.id) && styles.platformButtonSelected,
                  selectedPlatforms.length >= maxPlatforms && 
                  !selectedPlatforms.includes(platform.id) && 
                  styles.platformButtonDisabled
                ]}
                onPress={() => togglePlatform(platform.id)}
                disabled={selectedPlatforms.length >= maxPlatforms && !selectedPlatforms.includes(platform.id)}
              >
                <platform.icon 
                  size={20} 
                  color={selectedPlatforms.includes(platform.id) ? '#FFFFFF' : platform.color} 
                />
                <Text 
                  style={[
                    styles.platformButtonText,
                    selectedPlatforms.includes(platform.id) && styles.platformButtonTextSelected
                  ]}
                >
                  {platform.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        <TextInput
          style={styles.composeInput}
          placeholder="What would you like to share?"
          placeholderTextColor="#9CA3AF"
          multiline
          value={postText}
          onChangeText={setPostText}
        />
        
        <View style={styles.composeActions}>
          <View style={styles.mediaButtons}>
            <TouchableOpacity style={styles.mediaButton}>
              <ImageIcon size={20} color="#0B3D91" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.mediaButton}>
              <Smile size={20} color="#0B3D91" />
            </TouchableOpacity>
          </View>
          
          <View style={styles.postButtons}>
            {hasScheduling && (
              <TouchableOpacity style={styles.scheduleButton}>
                <Calendar size={20} color="#0B3D91" />
                <Text style={styles.scheduleButtonText}>Schedule</Text>
              </TouchableOpacity>
            )}
            
            <TouchableOpacity 
              style={[
                styles.postButton,
                (!postText.trim() || selectedPlatforms.length === 0) && styles.postButtonDisabled
              ]}
              disabled={!postText.trim() || selectedPlatforms.length === 0}
            >
              <Text style={styles.postButtonText}>Post Now</Text>
              <Send size={16} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        </View>
      </View>
      
      {hasScheduling && scheduledPosts.length > 0 && (
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Scheduled Posts</Text>
            <TouchableOpacity>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          
          {scheduledPosts.map(post => (
            <View key={post.id} style={styles.postCard}>
              <View style={styles.postHeader}>
                <View style={styles.postPlatforms}>
                  {post.platforms.map(platformId => (
                    <View key={platformId} style={styles.postPlatform}>
                      {renderPlatformIcon(platformId)}
                    </View>
                  ))}
                </View>
                <View style={styles.postSchedule}>
                  <Calendar size={14} color="#6B7280" />
                  <Text style={styles.postScheduleText}>{formatScheduleDate(post.scheduledFor)}</Text>
                  <Clock size={14} color="#6B7280" />
                  <Text style={styles.postScheduleText}>{formatScheduleTime(post.scheduledFor)}</Text>
                </View>
              </View>
              
              <Text style={styles.postContent}>{post.content}</Text>
              
              {post.image && (
                <Image
                  source={{ uri: post.image }}
                  style={styles.postImage}
                  resizeMode="cover"
                />
              )}
              
              <View style={styles.postActions}>
                <TouchableOpacity style={styles.postAction}>
                  <Text style={styles.postActionText}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.postAction}>
                  <Text style={[styles.postActionText, styles.deleteText]}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      )}
      
      {draftPosts.length > 0 && (
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Drafts</Text>
            <TouchableOpacity>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          
          {draftPosts.map(post => (
            <View key={post.id} style={styles.postCard}>
              <View style={styles.postHeader}>
                <View style={styles.postPlatforms}>
                  {post.platforms.map(platformId => (
                    <View key={platformId} style={styles.postPlatform}>
                      {renderPlatformIcon(platformId)}
                    </View>
                  ))}
                </View>
                <View style={styles.draftBadge}>
                  <Text style={styles.draftText}>Draft</Text>
                </View>
              </View>
              
              <Text style={styles.postContent}>{post.content}</Text>
              
              {post.image && (
                <Image
                  source={{ uri: post.image }}
                  style={styles.postImage}
                  resizeMode="cover"
                />
              )}
              
              <View style={styles.postActions}>
                <TouchableOpacity style={styles.postAction}>
                  <Text style={styles.postActionText}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.postAction, styles.postActionPrimary]}>
                  <Text style={styles.postActionPrimaryText}>Post Now</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      )}
      
      <TouchableOpacity style={styles.addContentButton}>
        <Plus size={20} color="#FFFFFF" />
        <Text style={styles.addContentText}>Create Campaign</Text>
      </TouchableOpacity>
      
      {!hasScheduling && (
        <View style={styles.upgradeCard}>
          <Text style={styles.upgradeTitle}>Unlock Advanced Features</Text>
          <Text style={styles.upgradeDescription}>
            Upgrade to our Pro plan to schedule posts across multiple platforms and access advanced analytics.
          </Text>
          <TouchableOpacity style={styles.upgradeButton}>
            <Text style={styles.upgradeButtonText}>Upgrade Now</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  contentContainer: {
    paddingBottom: 40,
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 24,
    color: '#1F2937',
  },
  composeCard: {
    backgroundColor: '#FFFFFF',
    margin: 20,
    padding: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  composeTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#1F2937',
    marginBottom: 16,
  },
  platformSelector: {
    marginBottom: 16,
  },
  selectorLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#4B5563',
    marginBottom: 8,
  },
  platformButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  platformButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginRight: 8,
    marginBottom: 8,
  },
  platformButtonSelected: {
    backgroundColor: '#0B3D91',
  },
  platformButtonDisabled: {
    opacity: 0.5,
  },
  platformButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#4B5563',
    marginLeft: 4,
  },
  platformButtonTextSelected: {
    color: '#FFFFFF',
  },
  composeInput: {
    height: 120,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    padding: 12,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#1F2937',
    textAlignVertical: 'top',
    marginBottom: 16,
  },
  composeActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  mediaButtons: {
    flexDirection: 'row',
  },
  mediaButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  postButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  scheduleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginRight: 8,
  },
  scheduleButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#0B3D91',
    marginLeft: 4,
  },
  postButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#0B3D91',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  postButtonDisabled: {
    backgroundColor: '#9CA3AF',
  },
  postButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#FFFFFF',
    marginRight: 8,
  },
  section: {
    marginHorizontal: 20,
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#1F2937',
  },
  viewAllText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#0B3D91',
  },
  postCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  postHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  postPlatforms: {
    flexDirection: 'row',
  },
  postPlatform: {
    marginRight: 8,
  },
  postSchedule: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 4,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  postScheduleText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#6B7280',
    marginHorizontal: 4,
  },
  draftBadge: {
    backgroundColor: '#F3F4F6',
    borderRadius: 4,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  draftText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#6B7280',
  },
  postContent: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 20,
    color: '#4B5563',
    marginBottom: 12,
  },
  postImage: {
    width: '100%',
    height: 160,
    borderRadius: 8,
    marginBottom: 12,
  },
  postActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  postAction: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    marginLeft: 8,
  },
  postActionPrimary: {
    backgroundColor: '#0B3D91',
    borderRadius: 4,
  },
  postActionText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#6B7280',
  },
  postActionPrimaryText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#FFFFFF',
  },
  deleteText: {
    color: '#EF4444',
  },
  addContentButton: {
    backgroundColor: '#0B3D91',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 8,
    marginBottom: 20,
  },
  addContentText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    marginLeft: 8,
  },
  upgradeCard: {
    backgroundColor: '#EBF5FF',
    margin: 20,
    padding: 20,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#BFDBFE',
  },
  upgradeTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#1E40AF',
    marginBottom: 8,
  },
  upgradeDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 20,
    color: '#3B82F6',
    marginBottom: 16,
  },
  upgradeButton: {
    backgroundColor: '#0B3D91',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  upgradeButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#FFFFFF',
  },
});