import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { Building2, Globe, ChevronRight } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';

export default function Onboarding() {
  const { user, updateUserProfile } = useAuth();
  const [companyName, setCompanyName] = useState('');
  const [website, setWebsite] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{
    companyName?: string;
    website?: string;
  }>({});

  const validateForm = () => {
    const newErrors: {
      companyName?: string;
      website?: string;
    } = {};
    
    if (!companyName) newErrors.companyName = 'Company name is required';
    
    if (website && !website.includes('.')) {
      newErrors.website = 'Please enter a valid website';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleComplete = async () => {
    if (!validateForm()) return;
    
    setIsLoading(true);
    try {
      // Update user profile
      updateUserProfile({
        companyName,
        profileComplete: true
      });
      
      // Navigate to main app
      setTimeout(() => {
        setIsLoading(false);
        router.replace('/(tabs)');
      }, 1000);
    } catch (error) {
      setIsLoading(false);
      console.error('Failed to complete onboarding:', error);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Set Up Your Profile</Text>
        <Text style={styles.subtitle}>
          Let's get your business profile set up so we can tailor your experience.
        </Text>
      </View>
      
      <View style={styles.formContainer}>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Company Name</Text>
          <View style={[styles.inputContainer, errors.companyName && styles.inputError]}>
            <Building2 size={20} color="#6B7280" style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder="Enter your company name"
              placeholderTextColor="#9CA3AF"
              value={companyName}
              onChangeText={setCompanyName}
            />
          </View>
          {errors.companyName && <Text style={styles.errorText}>{errors.companyName}</Text>}
        </View>
        
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Website URL (Optional)</Text>
          <View style={[styles.inputContainer, errors.website && styles.inputError]}>
            <Globe size={20} color="#6B7280" style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder="www.yourcompany.com"
              placeholderTextColor="#9CA3AF"
              keyboardType="url"
              autoCapitalize="none"
              value={website}
              onChangeText={setWebsite}
            />
          </View>
          {errors.website && <Text style={styles.errorText}>{errors.website}</Text>}
        </View>
        
        <View style={styles.subscriptionPrompt}>
          <Text style={styles.subscriptionTitle}>Choose a Plan</Text>
          <Text style={styles.subscriptionText}>
            You can select a subscription plan later, but you'll start with our free tier.
          </Text>
          
          <TouchableOpacity 
            style={styles.planCard}
            onPress={() => router.push('/subscription')}
          >
            <View style={styles.planInfo}>
              <Text style={styles.planName}>Free Plan</Text>
              <Text style={styles.planDescription}>Get started with basic marketing tools</Text>
            </View>
            <ChevronRight size={20} color="#0B3D91" />
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity 
          style={styles.continueButton}
          onPress={handleComplete}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Text style={styles.continueButtonText}>Continue to Dashboard</Text>
          )}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#FFFFFF',
    padding: 24,
  },
  header: {
    marginTop: 60,
    marginBottom: 40,
  },
  title: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 28,
    color: '#0B3D91',
    marginBottom: 12,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    lineHeight: 24,
    color: '#6B7280',
  },
  formContainer: {
    flex: 1,
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#374151',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#F9FAFB',
  },
  inputError: {
    borderColor: '#EF4444',
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#1F2937',
  },
  errorText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#EF4444',
    marginTop: 8,
  },
  subscriptionPrompt: {
    marginTop: 16,
    marginBottom: 32,
  },
  subscriptionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#1F2937',
    marginBottom: 8,
  },
  subscriptionText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 20,
    color: '#6B7280',
    marginBottom: 16,
  },
  planCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    padding: 16,
    marginTop: 8,
  },
  planInfo: {
    flex: 1,
  },
  planName: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#1F2937',
    marginBottom: 4,
  },
  planDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#6B7280',
  },
  continueButton: {
    backgroundColor: '#0B3D91',
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  continueButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
  },
});