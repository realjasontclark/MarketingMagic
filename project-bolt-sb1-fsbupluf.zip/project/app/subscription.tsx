import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { ArrowLeft, Check, X } from 'lucide-react-native';
import { useSubscription, subscriptionPlans, SubscriptionPlan } from '@/contexts/SubscriptionContext';
import { LinearGradient } from 'expo-linear-gradient';

export default function Subscription() {
  const { currentPlan, changePlan, isLoading } = useSubscription();
  const [selectedPlan, setSelectedPlan] = useState<string>(currentPlan?.id || 'free');
  
  const handleSelectPlan = (planId: string) => {
    setSelectedPlan(planId);
  };
  
  const handleSubscribe = async () => {
    try {
      await changePlan(selectedPlan);
      router.replace('/(tabs)');
    } catch (error) {
      console.error('Failed to change subscription:', error);
    }
  };

  const renderFeatureStatus = (available: boolean) => {
    return available ? (
      <View style={styles.featureAvailable}>
        <Check size={16} color="#047857" />
      </View>
    ) : (
      <View style={styles.featureUnavailable}>
        <X size={16} color="#DC2626" />
      </View>
    );
  };

  const renderPlanCard = (plan: SubscriptionPlan) => {
    const isSelected = selectedPlan === plan.id;
    const isCurrentPlan = currentPlan?.id === plan.id;
    
    return (
      <TouchableOpacity
        key={plan.id}
        style={[
          styles.planCard,
          isSelected && styles.planCardSelected
        ]}
        onPress={() => handleSelectPlan(plan.id)}
      >
        {plan.tier === 'pro' && (
          <View style={styles.popularBadge}>
            <Text style={styles.popularText}>Popular</Text>
          </View>
        )}
        
        <Text style={styles.planName}>{plan.name}</Text>
        <View style={styles.priceContainer}>
          <Text style={styles.price}>
            ${plan.price}
            <Text style={styles.pricePeriod}>/mo</Text>
          </Text>
        </View>
        
        <View style={styles.featuresList}>
          <View style={styles.featureItem}>
            {renderFeatureStatus(true)}
            <Text style={styles.featureText}>
              {plan.features.contentGeneration.postsPerMonth} content pieces/month
            </Text>
          </View>
          
          <View style={styles.featureItem}>
            {renderFeatureStatus(plan.features.seo.keywordResearch)}
            <Text style={styles.featureText}>
              Keyword research
            </Text>
          </View>
          
          <View style={styles.featureItem}>
            {renderFeatureStatus(plan.features.seo.competitorAnalysis)}
            <Text style={styles.featureText}>
              Competitor analysis
            </Text>
          </View>
          
          <View style={styles.featureItem}>
            {renderFeatureStatus(plan.features.socialMedia.scheduling)}
            <Text style={styles.featureText}>
              Social media scheduling
            </Text>
          </View>
          
          <View style={styles.featureItem}>
            {renderFeatureStatus(plan.features.socialMedia.analytics)}
            <Text style={styles.featureText}>
              Performance analytics
            </Text>
          </View>
          
          <View style={styles.featureItem}>
            {renderFeatureStatus(plan.features.email.automation)}
            <Text style={styles.featureText}>
              Email automation
            </Text>
          </View>
        </View>
        
        {isCurrentPlan && (
          <View style={styles.currentPlanBadge}>
            <Text style={styles.currentPlanText}>Current Plan</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color="#0B3D91" />
        </TouchableOpacity>
        <Text style={styles.title}>Choose Your Plan</Text>
      </View>
      
      <Text style={styles.subtitle}>
        Select the plan that best fits your business needs. All plans include access to our marketing tools.
      </Text>
      
      <View style={styles.plansContainer}>
        {subscriptionPlans.map(renderPlanCard)}
      </View>
      
      <TouchableOpacity 
        style={styles.subscribeButton}
        onPress={handleSubscribe}
        disabled={isLoading || (currentPlan?.id === selectedPlan)}
      >
        {isLoading ? (
          <ActivityIndicator size="small" color="#FFFFFF" />
        ) : (
          <Text style={styles.subscribeButtonText}>
            {currentPlan?.id === selectedPlan 
              ? 'Current Plan' 
              : currentPlan 
                ? 'Change Plan' 
                : 'Subscribe Now'}
          </Text>
        )}
      </TouchableOpacity>
      
      <Text style={styles.disclaimer}>
        You can change or cancel your subscription at any time. All plans are billed monthly.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#FFFFFF',
    padding: 24,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 40,
    marginBottom: 24,
  },
  backButton: {
    padding: 8,
  },
  title: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 24,
    color: '#0B3D91',
    marginLeft: 16,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    lineHeight: 24,
    color: '#6B7280',
    marginBottom: 32,
  },
  plansContainer: {
    marginBottom: 32,
  },
  planCard: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    padding: 24,
    marginBottom: 24,
    backgroundColor: '#FFFFFF',
    position: 'relative',
  },
  planCardSelected: {
    borderColor: '#0B3D91',
    borderWidth: 2,
    shadowColor: '#0B3D91',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 4,
  },
  popularBadge: {
    position: 'absolute',
    top: -12,
    right: 24,
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 16,
  },
  popularText: {
    fontFamily: 'Inter-Bold',
    fontSize: 12,
    color: '#FFFFFF',
  },
  planName: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: '#1F2937',
    marginBottom: 8,
  },
  priceContainer: {
    marginBottom: 20,
  },
  price: {
    fontFamily: 'Poppins-Bold',
    fontSize: 32,
    color: '#0B3D91',
  },
  pricePeriod: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#6B7280',
  },
  featuresList: {
    marginTop: 16,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureAvailable: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#DCFCE7',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  featureUnavailable: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#FEE2E2',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  featureText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4B5563',
  },
  currentPlanBadge: {
    backgroundColor: '#E0F2FE',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    alignSelf: 'flex-start',
    marginTop: 16,
  },
  currentPlanText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#0369A1',
  },
  subscribeButton: {
    backgroundColor: '#0B3D91',
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  subscribeButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
  },
  disclaimer: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    textAlign: 'center',
    color: '#6B7280',
    marginBottom: 24,
  },
});