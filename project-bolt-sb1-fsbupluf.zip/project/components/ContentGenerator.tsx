import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ActivityIndicator, ScrollView } from 'react-native';
import { Wand2, Copy, Check, Save } from 'lucide-react-native';
import { useSubscription } from '@/contexts/SubscriptionContext';

type ContentType = 'social' | 'email' | 'blog' | 'ad';

interface ContentTemplate {
  id: string;
  title: string;
  description: string;
  type: ContentType;
  prompt: string;
}

export const ContentGenerator: React.FC = () => {
  const { currentPlan, getFeatureLimit } = useSubscription();
  const [selectedType, setSelectedType] = useState<ContentType>('social');
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const contentTemplates: ContentTemplate[] = [
    { 
      id: 'social1', 
      title: 'Product Promotion', 
      type: 'social',
      description: 'Promote your product with engaging copy',
      prompt: 'Create an engaging social media post promoting my product: ' 
    },
    { 
      id: 'social2', 
      title: 'Event Announcement', 
      type: 'social',
      description: 'Announce an upcoming event',
      prompt: 'Create a social media announcement for an upcoming event: ' 
    },
    { 
      id: 'email1', 
      title: 'Welcome Email', 
      type: 'email',
      description: 'Welcome new subscribers to your list',
      prompt: 'Write a welcome email for new subscribers to my newsletter about: ' 
    },
    { 
      id: 'blog1', 
      title: 'How-to Guide', 
      type: 'blog',
      description: 'Create a step-by-step tutorial',
      prompt: 'Write a how-to guide about: ' 
    },
    { 
      id: 'ad1', 
      title: 'Facebook Ad', 
      type: 'ad',
      description: 'Compelling ad copy for Facebook',
      prompt: 'Write a Facebook ad for: ' 
    },
  ];
  
  const filteredTemplates = contentTemplates.filter(template => template.type === selectedType);
  
  const postsLimit = getFeatureLimit('contentGeneration.postsPerMonth') || 0;
  const postsUsed = 2; // This would come from an API in a real app
  
  const handleSelectTemplate = (template: ContentTemplate) => {
    setPrompt(template.prompt);
  };
  
  const handleGenerateContent = async () => {
    if (!prompt.trim()) {
      setError('Please enter a prompt or select a template');
      return;
    }
    
    if (postsUsed >= postsLimit) {
      setError(`You've reached your monthly limit of ${postsLimit} content generations. Upgrade your plan for more.`);
      return;
    }
    
    setError(null);
    setIsGenerating(true);
    
    try {
      // This would be an API call in a real app
      // For the demo, we'll just wait and return mock content
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock generated content based on the prompt
      let result = '';
      if (prompt.includes('social media')) {
        result = "✨ Exciting news! We're launching our new product next week. Be the first to get exclusive access and special pricing. Like and share to spread the word! #NewLaunch #ExcitingTimes";
      } else if (prompt.includes('email')) {
        result = "Subject: Welcome to Our Community!\n\nHi there,\n\nWe're thrilled to have you join our newsletter. Get ready for expert tips, industry insights, and exclusive offers delivered straight to your inbox.\n\nStay tuned for our next email where we'll share our top 5 strategies for growth.\n\nBest regards,\nThe Team";
      } else if (prompt.includes('blog')) {
        result = "# How to Optimize Your Website for Better Conversions\n\n## Introduction\nConversion optimization is crucial for any business looking to maximize their online presence...\n\n## Step 1: Analyze Your Current Performance\nBefore making any changes, it's important to understand your baseline metrics...\n\n## Step 2: Identify Conversion Bottlenecks\nLook for pages with high exit rates or abandonment...";
      } else {
        result = "Generated content based on your prompt: " + prompt + "\n\nThis is where your AI-generated marketing content would appear. In a real implementation, this would connect to an API like OpenAI to generate relevant, high-quality content based on your specific prompt and business needs.";
      }
      
      setGeneratedContent(result);
    } catch (err) {
      setError('Failed to generate content. Please try again.');
      console.error('Content generation error:', err);
    } finally {
      setIsGenerating(false);
    }
  };
  
  const handleCopyContent = () => {
    if (generatedContent) {
      // In a real app, you would use Clipboard.setString(generatedContent)
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };
  
  const handleSaveContent = () => {
    // In a real app, this would save to a database
    alert('Content saved successfully!');
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.header}>
        <Text style={styles.title}>Content Generator</Text>
        <View style={styles.usageCounter}>
          <Text style={styles.usageText}>
            {postsUsed} / {postsLimit} generations used this month
          </Text>
        </View>
      </View>
      
      <View style={styles.typeSelector}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <TouchableOpacity
            style={[styles.typeButton, selectedType === 'social' && styles.typeButtonActive]}
            onPress={() => setSelectedType('social')}
          >
            <Text style={[styles.typeButtonText, selectedType === 'social' && styles.typeButtonTextActive]}>
              Social Media
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.typeButton, selectedType === 'email' && styles.typeButtonActive]}
            onPress={() => setSelectedType('email')}
          >
            <Text style={[styles.typeButtonText, selectedType === 'email' && styles.typeButtonTextActive]}>
              Email
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.typeButton, selectedType === 'blog' && styles.typeButtonActive]}
            onPress={() => setSelectedType('blog')}
          >
            <Text style={[styles.typeButtonText, selectedType === 'blog' && styles.typeButtonTextActive]}>
              Blog
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.typeButton, selectedType === 'ad' && styles.typeButtonActive]}
            onPress={() => setSelectedType('ad')}
          >
            <Text style={[styles.typeButtonText, selectedType === 'ad' && styles.typeButtonTextActive]}>
              Ads
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
      
      <View style={styles.templateSelector}>
        <Text style={styles.sectionTitle}>Templates</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {filteredTemplates.map(template => (
            <TouchableOpacity
              key={template.id}
              style={styles.templateCard}
              onPress={() => handleSelectTemplate(template)}
            >
              <Text style={styles.templateTitle}>{template.title}</Text>
              <Text style={styles.templateDescription}>{template.description}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      
      <View style={styles.promptContainer}>
        <Text style={styles.sectionTitle}>Your Prompt</Text>
        <TextInput
          style={styles.promptInput}
          placeholder="Describe what you want to generate..."
          placeholderTextColor="#9CA3AF"
          multiline
          value={prompt}
          onChangeText={setPrompt}
        />
        
        {error && (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}
        
        <TouchableOpacity
          style={styles.generateButton}
          onPress={handleGenerateContent}
          disabled={isGenerating || !prompt.trim()}
        >
          {isGenerating ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <>
              <Wand2 size={20} color="#FFFFFF" style={{ marginRight: 8 }} />
              <Text style={styles.generateButtonText}>Generate Content</Text>
            </>
          )}
        </TouchableOpacity>
      </View>
      
      {generatedContent && (
        <View style={styles.resultContainer}>
          <View style={styles.resultHeader}>
            <Text style={styles.resultTitle}>Generated Content</Text>
            <View style={styles.resultActions}>
              <TouchableOpacity style={styles.actionButton} onPress={handleCopyContent}>
                {copied ? (
                  <Check size={20} color="#15803D" />
                ) : (
                  <Copy size={20} color="#0B3D91" />
                )}
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.actionButton} onPress={handleSaveContent}>
                <Save size={20} color="#0B3D91" />
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.contentBox}>
            <Text style={styles.generatedText}>{generatedContent}</Text>
          </View>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  contentContainer: {
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: '#1F2937',
  },
  usageCounter: {
    backgroundColor: '#E0F2FE',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  usageText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#0369A1',
  },
  typeSelector: {
    marginBottom: 24,
  },
  typeButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
    backgroundColor: '#F3F4F6',
  },
  typeButtonActive: {
    backgroundColor: '#0B3D91',
  },
  typeButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#6B7280',
  },
  typeButtonTextActive: {
    color: '#FFFFFF',
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#374151',
    marginBottom: 12,
  },
  templateSelector: {
    marginBottom: 24,
  },
  templateCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    width: 180,
    marginRight: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  templateTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#1F2937',
    marginBottom: 8,
  },
  templateDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#6B7280',
  },
  promptContainer: {
    marginBottom: 24,
  },
  promptInput: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    height: 120,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#1F2937',
    textAlignVertical: 'top',
    marginBottom: 16,
  },
  errorContainer: {
    backgroundColor: '#FEE2E2',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  errorText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: '#B91C1C',
  },
  generateButton: {
    backgroundColor: '#0B3D91',
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  generateButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
  },
  resultContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#1F2937',
  },
  resultActions: {
    flexDirection: 'row',
  },
  actionButton: {
    padding: 8,
    marginLeft: 8,
  },
  contentBox: {
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
    padding: 16,
  },
  generatedText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 22,
    color: '#4B5563',
  },
});