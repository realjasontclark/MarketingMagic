import React, { createContext, useState, useContext, useEffect } from 'react';
import { router } from 'expo-router';

interface User {
  id: string;
  email: string;
  name: string;
  companyName?: string;
  profileComplete: boolean;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string) => Promise<void>;
  signOut: () => void;
  updateUserProfile: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  signIn: async () => {},
  signUp: async () => {},
  signOut: () => {},
  updateUserProfile: () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user credentials
    const checkAuthStatus = async () => {
      try {
        // This would normally be a check to Firebase, AsyncStorage, etc.
        // For demo purposes, we'll just use a timeout
        setTimeout(() => {
          // For now, we'll start with no user
          setUser(null);
          setIsLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Failed to check auth status:', error);
        setIsLoading(false);
      }
    };

    checkAuthStatus();
  }, []);

  const signIn = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // Mock authentication
      // In a real app, this would call Firebase auth or another service
      setTimeout(() => {
        const mockUser: User = {
          id: 'user123',
          email,
          name: 'Demo User',
          companyName: 'ABC Company',
          profileComplete: true,
        };
        setUser(mockUser);
        setIsLoading(false);
        router.replace('/(tabs)');
      }, 1000);
    } catch (error) {
      console.error('Sign in failed:', error);
      setIsLoading(false);
      throw error;
    }
  };

  const signUp = async (email: string, password: string, name: string) => {
    setIsLoading(true);
    try {
      // Mock signup
      // In a real app, this would call Firebase auth or another service
      setTimeout(() => {
        const mockUser: User = {
          id: 'user123',
          email,
          name,
          profileComplete: false,
        };
        setUser(mockUser);
        setIsLoading(false);
        router.replace('/onboarding');
      }, 1000);
    } catch (error) {
      console.error('Sign up failed:', error);
      setIsLoading(false);
      throw error;
    }
  };

  const signOut = () => {
    // Clear user data
    setUser(null);
    router.replace('/(auth)');
  };

  const updateUserProfile = (data: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...data });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        signIn,
        signUp,
        signOut,
        updateUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};