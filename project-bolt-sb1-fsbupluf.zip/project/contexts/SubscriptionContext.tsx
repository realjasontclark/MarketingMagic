import React, { createContext, useState, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';

export type SubscriptionTier = 'free' | 'basic' | 'pro' | 'enterprise';

interface SubscriptionFeatures {
  contentGeneration: {
    postsPerMonth: number;
    advancedTools: boolean;
  };
  seo: {
    keywordResearch: boolean;
    competitorAnalysis: boolean;
    rankTracking: boolean;
  };
  socialMedia: {
    platforms: number;
    scheduling: boolean;
    analytics: boolean;
  };
  email: {
    campaignsPerMonth: number;
    templates: number;
    automation: boolean;
  };
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  tier: SubscriptionTier;
  price: number;
  features: SubscriptionFeatures;
}

interface SubscriptionContextType {
  currentPlan: SubscriptionPlan | null;
  availablePlans: SubscriptionPlan[];
  isLoading: boolean;
  changePlan: (planId: string) => Promise<void>;
  getFeatureLimit: (feature: string) => any;
  canAccessFeature: (feature: string) => boolean;
}

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'free',
    name: 'Free',
    tier: 'free',
    price: 0,
    features: {
      contentGeneration: {
        postsPerMonth: 5,
        advancedTools: false,
      },
      seo: {
        keywordResearch: true,
        competitorAnalysis: false,
        rankTracking: false,
      },
      socialMedia: {
        platforms: 1,
        scheduling: false,
        analytics: false,
      },
      email: {
        campaignsPerMonth: 1,
        templates: 3,
        automation: false,
      },
    },
  },
  {
    id: 'basic',
    name: 'Basic',
    tier: 'basic',
    price: 29.99,
    features: {
      contentGeneration: {
        postsPerMonth: 20,
        advancedTools: false,
      },
      seo: {
        keywordResearch: true,
        competitorAnalysis: true,
        rankTracking: false,
      },
      socialMedia: {
        platforms: 3,
        scheduling: true,
        analytics: false,
      },
      email: {
        campaignsPerMonth: 5,
        templates: 10,
        automation: false,
      },
    },
  },
  {
    id: 'pro',
    name: 'Professional',
    tier: 'pro',
    price: 79.99,
    features: {
      contentGeneration: {
        postsPerMonth: 50,
        advancedTools: true,
      },
      seo: {
        keywordResearch: true,
        competitorAnalysis: true,
        rankTracking: true,
      },
      socialMedia: {
        platforms: 5,
        scheduling: true,
        analytics: true,
      },
      email: {
        campaignsPerMonth: 20,
        templates: 25,
        automation: true,
      },
    },
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    tier: 'enterprise',
    price: 199.99,
    features: {
      contentGeneration: {
        postsPerMonth: 150,
        advancedTools: true,
      },
      seo: {
        keywordResearch: true,
        competitorAnalysis: true,
        rankTracking: true,
      },
      socialMedia: {
        platforms: 10,
        scheduling: true,
        analytics: true,
      },
      email: {
        campaignsPerMonth: 50,
        templates: 50,
        automation: true,
      },
    },
  },
];

const SubscriptionContext = createContext<SubscriptionContextType>({
  currentPlan: null,
  availablePlans: subscriptionPlans,
  isLoading: true,
  changePlan: async () => {},
  getFeatureLimit: () => null,
  canAccessFeature: () => false,
});

export const useSubscription = () => useContext(SubscriptionContext);

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [currentPlan, setCurrentPlan] = useState<SubscriptionPlan | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadSubscription = async () => {
      if (user) {
        try {
          // For demo purposes, we'll use a mock plan
          // In a real app, this would come from an API or database
          setTimeout(() => {
            setCurrentPlan(subscriptionPlans[0]); // Default to free plan
            setIsLoading(false);
          }, 1000);
        } catch (error) {
          console.error('Failed to load subscription:', error);
          setIsLoading(false);
        }
      } else {
        setCurrentPlan(null);
        setIsLoading(false);
      }
    };

    loadSubscription();
  }, [user]);

  const changePlan = async (planId: string) => {
    setIsLoading(true);
    try {
      // Mock plan change
      // In a real app, this would call an API to handle subscription changes
      const newPlan = subscriptionPlans.find(plan => plan.id === planId);
      if (!newPlan) throw new Error('Plan not found');
      
      setTimeout(() => {
        setCurrentPlan(newPlan);
        setIsLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Failed to change plan:', error);
      setIsLoading(false);
      throw error;
    }
  };

  const getFeatureLimit = (feature: string) => {
    if (!currentPlan) return null;
    
    // Navigate the nested feature object
    const path = feature.split('.');
    let value: any = currentPlan.features;
    
    for (const key of path) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        return null;
      }
    }
    
    return value;
  };

  const canAccessFeature = (feature: string) => {
    const limit = getFeatureLimit(feature);
    if (typeof limit === 'boolean') return limit;
    if (typeof limit === 'number') return limit > 0;
    return false;
  };

  return (
    <SubscriptionContext.Provider
      value={{
        currentPlan,
        availablePlans: subscriptionPlans,
        isLoading,
        changePlan,
        getFeatureLimit,
        canAccessFeature,
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
};